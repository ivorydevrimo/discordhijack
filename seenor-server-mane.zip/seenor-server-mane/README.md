# txnor-server
Server software running on txnor.com for the Discord s/e/x "hack".

`txnor.nginx` is an nginx site configuration.

Note: You'll have to supply your own impact.ttf for the main part and ginto fonts for the swordgame part
